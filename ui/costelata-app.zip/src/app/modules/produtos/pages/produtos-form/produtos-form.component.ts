import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-produtos-form',
  templateUrl: './produtos-form.component.html',
  styleUrls: ['./produtos-form.component.css']
})
export class ProdutosFormComponent implements OnInit {
  produtoForm!: FormGroup;

  categorias: any [] = [//Categoria[] = [
    { id: 'cat1', nome: 'Carnes' },
    { id: 'cat2', nome: 'Bebidas' }
  ];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.contruirForm();
    this.carregarCategorias();
  }

  contruirForm() {
    this.produtoForm = this.fb.group({
      codigo: ['', Validators.required],
      descricao: ['', [Validators.required, Validators.minLength(3)]],
      descricaoDetalhada: [''],
      unidade: ['', Validators.required],
      valorUnitario: [0, [Validators.required, Validators.min(0.01)]],
      codigoCategoria: [null, Validators.required]
    });
  }

  carregarCategorias() {
    this.categorias = [
      { id: 'cat1', nome: 'Carnes' },
      { id: 'cat2', nome: 'Bebidas' },
      { id: 'cat3', nome: 'Acompanhamentos' },
      { id: 'cat4', nome: 'Sobremesas' }
    ];
  }

  salvarProduto() {
    if (this.produtoForm.valid) {
      const produto: any = this.produtoForm.value; //Produto = this.produtoForm.value;
      console.log('Produto salvo:', produto);
      // this.produtoService.salvar(produto).subscribe(...)
    }
  }

  voltar() {
    // this.router.navigate(['/produtos']);
  }
}
