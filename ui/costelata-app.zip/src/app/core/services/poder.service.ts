import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PoderService {

  constructor() { }

  listarPoder() {
    return [
      { id: 1, descricao: 'Executivo', valor: 'EXECUTIVO' },
      { id: 2, descricao: 'Legislativo', valor: 'LEGISLATIVO' },
      { id: 3, descricao: 'Judiciário', valor: 'JUDICIARIO' },
      { id: 4, descricao: 'Educacional', valor: 'EDUCACIONAL' },
      { id: 5, descricao: 'Militar', valor: 'MILITAR' },
      { id: 6, descricao: 'Diplomático', valor: 'DIPLOMATICO' },
      { id: 7, descricao: 'Comunitário', valor: 'COMUNITARIO' }
    ];
  }
}
