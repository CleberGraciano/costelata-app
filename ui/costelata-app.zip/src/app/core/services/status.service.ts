import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StatusService {

  constructor() { }

  listarStatus() {
    return [
      { valor: 'ATIVO', descricao: 'ATIVO' },
      { valor: 'INATIVO', descricao: 'INATIVO' }
    ];
  }
}
