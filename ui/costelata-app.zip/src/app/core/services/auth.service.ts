import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {user} from 'auth-user';
import {environment} from 'src/environments/environment';
import {BehaviorSubject, catchError, map, Observable, throwError} from 'rxjs';
import { NgxPermissionsService } from 'ngx-permissions';
import { PermissaoEnum } from '@core/enum/permissao.enum';

const URL_BASE = environment.apiAuth;
const authUser = user;

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user = new BehaviorSubject<any>('');
  user$ = this.user.asObservable();
  constructor(
    private httpClient: HttpClient,
    private permissionService: NgxPermissionsService
  ) {}

  authUser(ticket: { [x: string]: any; ticket?: any; }): Observable<any> {
    return this.httpClient
      .post(`${URL_BASE}/login`, { ...authUser, token: ticket.ticket })
      .pipe(
        map((response: any) => {
          sessionStorage.setItem('token', response?.token);
          sessionStorage.setItem('user', response?.user?.usuario?.nome);
          sessionStorage.setItem('cpf', response?.user?.usuario?.cpfCnpj);
          sessionStorage.setItem('usuarioCasId', response?.user?.usuario?.idUsuario);
          sessionStorage.setItem('permissoes', JSON.stringify(response?.user?.permissoes));
          this.permissionService.loadPermissions(response?.user?.permissoes);
          this.user.next(response?.user?.usuario?.nome);
          return response;
        })
      )
      .pipe(
        catchError((error: any) => {
          return throwError(error);
        })
      );
  }
}
