import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService } from '@core/services/api.service';
import { MessageService } from 'primeng/api';
import { filter } from 'rxjs';


const baseRef = '/esferas';
const routes = {
  filter: `${baseRef}`,
  filterById: (id: number) => `${baseRef}/${id}`,
  filterCombos: `${baseRef}/resumo`,
  insert: `${baseRef}/eventos`,
  edit: (id: number) => `${baseRef}/eventos/${id}`,
  delete: (id: number) => `${baseRef}/eventos/${id}`,
  niveisEsfera: `${baseRef}/niveis`
}

@Injectable({
  providedIn: 'root'
})
export class EsferaService {

  constructor(
    private apiService: ApiService,
    private http: HttpClient,
    private messageService: MessageService,
  ) { }

  filter(obj: any) {
    let params = new HttpParams();
    params = params.append('nivel', obj.nivel);
    params = params.append('descricaoEsfera', obj.descricaoEsfera);
    return this.apiService.get<any>(`${routes.filter}`, false, params);
  }

  filterCombos() {
    return this.apiService.get<any>(routes.filterCombos);
  }

  itemById(id: number) {
    return this.apiService.get<any>(routes.filterById(id));
  }

  insert(obj: any) {
    return this.apiService.post<any>(routes.insert, obj);
  }

  edit(id: number, obj: any) {
    return this.apiService.put<any>(routes.edit(id), obj);
  }

  delete(id: number) {
    return this.apiService.delete(routes.delete(id));
  }

  listarNiveisEsfera() {
    return [
      { id: 1, descricao: 'Esfera 1 - Chefia de Estado e Governo Federal', valor: 'ESFERA_1' },
      { id: 2, descricao: 'Esfera 2 - Chefia Estadual', valor: 'ESFERA_2' },
      { id: 3, descricao: 'Esfera 3 - Chefia Municipal', valor: 'ESFERA_3' },
      { id: 4, descricao: 'Esfera 4 - Outras Autoridades com Relevância Estratégica', valor: 'ESFERA_4' },
    ];
  }

  listarDescricaoEsfera() {
    return [
      { id: 1, descricao: 'Federal', valor: 'FEDERAL' },
      { id: 2, descricao: 'Estadual', valor: 'ESTADUAL' },
      { id: 3, descricao: 'Municipal', valor: 'MUNICIPAL' },
      { id: 4, descricao: 'Federal/Estadual', valor: 'FEDERAL_ESTADUAL' },
      { id: 5, descricao: 'Estadual/Federal', valor: 'ESTADUAL_FEDERAL' },
      { id: 6, descricao: 'Nacional', valor: 'NACIONAL' }
    ];
  }

  niveisEsfera(idsOrgaos: any) {
    let params = new HttpParams();
    params = params.append('idsOrgao', idsOrgaos);
    return this.apiService.get<any>(`${routes.niveisEsfera}`, false, params);
  }
}
