export enum PermissaoEnum {
  Operador = 'OPERADOR',
  GestorEvento = 'GESTOR_EVENTOS',
  Participante = 'PARTICIPANTE'
}
