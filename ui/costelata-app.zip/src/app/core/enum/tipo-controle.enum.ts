export enum TipoControle {
  REGISTRO_PRESENCA = 'Registro de Presença',
  CONTROLE_ACESSO = 'Controle de acesso'
}
