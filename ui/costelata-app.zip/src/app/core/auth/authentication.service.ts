import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {delay} from 'rxjs/operators';
import {LocalStorageService} from '@core/local-storage/local-storage.service';
import {Router} from '@angular/router';
import {environment} from '@env/environment';

const routes = {
    login: `signin`,
    forgotenPassword: (email: string) => `${email}/forgotpasswd`,
    changePassword: `user/changepasswd`
}

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private loggedIn = new BehaviorSubject<boolean>(false);

    constructor(
      private localStorageService: LocalStorageService,
        private router: Router
      ) {
        this.loggedIn = new BehaviorSubject<boolean>(sessionStorage.getItem('token') != undefined);
    }

    public get isLoggedIn() {
        return this.loggedIn.asObservable().pipe(delay(0));
    }

    public get isLoged(): boolean {
        return this.loggedIn.value;
    }

    logout() {
      sessionStorage.clear();
      // window.location.href = `${environment.redirectUrl}`;
    }
}
