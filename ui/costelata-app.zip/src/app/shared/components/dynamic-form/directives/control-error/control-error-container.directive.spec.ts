import { ControlErrorContainerDirective } from './control-error-container.directive';

describe('ControlErrorContainerDirective', () => {
  it('should create an instance', () => {
    const directive = new ControlErrorContainerDirective(null);
    expect(directive).toBeTruthy();
  });
});
