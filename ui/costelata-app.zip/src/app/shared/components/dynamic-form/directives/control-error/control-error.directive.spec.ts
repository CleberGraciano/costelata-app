import { ControlErrorDirective } from './control-error.directive';

describe('ControlErrorDirective', () => {
 /*  it('should create an instance', () => {
    const directive = new ControlErrorDirective();
    expect(directive).toBeTruthy();
  }); */
});
