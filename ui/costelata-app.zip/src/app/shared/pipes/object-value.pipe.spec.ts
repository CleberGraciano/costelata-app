import { ObjectValuePipe } from './object-value.pipe';

describe('ObjectValuePipe', () => {
  it('create an instance', () => {
    const pipe = new ObjectValuePipe();
    expect(pipe).toBeTruthy();
  });
});
