import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from '@shared/shared.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthorizationInterceptor } from '@core/guards/authorization.interceptor';

import { LOCALE_ID } from '@angular/core';
import { registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import { AuthenticationService } from '@core/auth/authentication.service';
import { LocalStorageService } from '@core/local-storage/local-storage.service';
import { LoaderComponent } from '@shared/components/loader/loader.component';
import { NgxPermissionsModule, NgxPermissionsService } from 'ngx-permissions';
import { AuthGuardService } from '@core/auth/auth-guard.service';
import {SidebarModule} from "primeng/sidebar";
import {PanelMenuModule} from "primeng/panelmenu";


registerLocaleData(localePt, 'pt-BR');

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule,
    LoaderComponent,
    NgxPermissionsModule.forRoot(),
    SidebarModule,
    PanelMenuModule,
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthorizationInterceptor,
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: loadPermissions,
      deps: [NgxPermissionsService],
      multi: true
    },
    AuthGuardService,
    NgxPermissionsService,
    AuthenticationService,
    LocalStorageService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


export function loadPermissions(permissionService: NgxPermissionsService) {
  return () => {
    const permissoes = sessionStorage.getItem('permissoes');

    if (permissoes) {
      permissionService.loadPermissions(JSON.parse(permissoes));
    }
  }
}
