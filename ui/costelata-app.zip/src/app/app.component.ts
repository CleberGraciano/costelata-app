import { Component, HostListener } from '@angular/core';

interface CarrinhoItem {
  nome: string;
  quantidade: number;
  preco: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  usuarioLogado: any = JSON.parse(localStorage.getItem('usuario') || 'null');
  menuAberto = false;
  isLargeScreen = window.innerWidth >= 1024;

  mostrarCarrinho = false;
  carrinho: CarrinhoItem[] = [];

  constructor() {
    this.menuAberto = this.isLargeScreen;

    const carrinhoLocal = localStorage.getItem('carrinho');

    if (!carrinhoLocal || carrinhoLocal === '[]') {
      const itemFicticio: CarrinhoItem[] = [
        { nome: 'Costela BBQ', quantidade: 2, preco: 59.9 }
      ];
      localStorage.setItem('carrinho', JSON.stringify(itemFicticio));
    }

    this.carregarCarrinho();
  }

  @HostListener('window:resize')
  onResize() {
    this.isLargeScreen = window.innerWidth >= 1024;
    if (this.isLargeScreen) {
      this.menuAberto = true;
    }
  }

  toggleMenu() {
    this.menuAberto = !this.menuAberto;
  }

  abrirCarrinho() {
    this.mostrarCarrinho = true;
  }

  fecharCarrinho() {
    this.mostrarCarrinho = false;
  }

  carregarCarrinho() {
    const dados = localStorage.getItem('carrinho');
    this.carrinho = dados ? JSON.parse(dados) : [];
  }

  alterarQuantidade(index: number, delta: number) {
    const item = this.carrinho[index];
    item.quantidade += delta;

    if (item.quantidade <= 0) {
      this.carrinho.splice(index, 1);
    }

    this.atualizarCarrinho();
  }

  removerItem(index: number) {
    this.carrinho.splice(index, 1);
    this.atualizarCarrinho();
  }

  finalizarCompra() {
    alert('Pedido finalizado com sucesso!');
    this.carrinho = [];
    localStorage.removeItem('carrinho');
    this.fecharCarrinho();
  }

  atualizarCarrinho() {
    localStorage.setItem('carrinho', JSON.stringify(this.carrinho));
  }

  get totalCarrinho(): number {
    return this.carrinho.reduce((total, item) => total + item.preco * item.quantidade, 0);
  }

  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('usuario');
    location.href = '/login';
  }
}
