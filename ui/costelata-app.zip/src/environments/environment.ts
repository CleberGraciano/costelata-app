export const environment = {
  production: false,
  version:'1.0',
  auth: '/auth',
  api: 'http://localhost:8080/api',
};
