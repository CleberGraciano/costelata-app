/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
    "./node_modules/primeng/**/*.{js,ts}"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50:  '#fff9f3',
          100: '#fef0db',
          200: '#fdcf85',
          300: '#f3b061',
          400: '#d57b57',
          500: '#b24f44',
          600: '#83332e',
          700: '#662926',
          800: '#4e211f',
          900: '#402020'
        }
      },
      fontFamily: {
        heading: ['"Big Shoulders Display"', 'sans-serif'],
        display: ['"Big Shoulders Display"', 'sans-serif'],
        body: ['Inter', 'sans-serif']
      }
    }
  },
  plugins: []
}
